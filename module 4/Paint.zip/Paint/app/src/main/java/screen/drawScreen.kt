package screen

// Assuming Line data class is defined in screen/Line.kt or directly here for brevity
// data class Line(val start: Offset, val end: Offset, val color: Color, val strokeWidth: Float)
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DrawScreen() {
    val lines = remember { mutableStateListOf<Line>() }
    var currentColor by remember { mutableStateOf(Color.Black) }
    var currentStrokeWidth by remember { mutableFloatStateOf(5f) }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        TopAppBar(
            title = { Text("Drawing App", fontWeight = FontWeight.Bold) },
            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                containerColor = MaterialTheme.colorScheme.primary,
                titleContentColor = Color.White
            )
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Slider for stroke width
            Spacer(modifier = Modifier.height(12.dp)) // Space between slider and buttons

            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                // First row of buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Slider(value = currentStrokeWidth,
                        onValueChange = { currentStrokeWidth = it },
                        valueRange = 1f..50f,
                        modifier = Modifier.weight(1f))
                    ColorButton(color = Color.White, text = "E", textColor = Color.Black) { currentColor = it }
                    ColorButton(color = Color.Black, text = "B") { currentColor = it }
                    ColorButton(color = Color.Red, text = "R") { currentColor = it }
                }

                Spacer(modifier = Modifier.height(8.dp)) // Space between button rows

                // Second row of buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    ColorButton(color = Color.DarkGray, text = "R") { currentColor = it }
                    ColorButton(color = Color.Yellow, text = "Y") { currentColor = it }
                    ColorButton(color = Color.Green, text = "G") { currentColor = it }
                    ColorButton(color = Color.Blue, text = "B") { currentColor = it }

                    // Clear Button
                    Button(
                        onClick = { lines.clear() },
                        enabled = lines.isNotEmpty(),
                        modifier = Modifier.width(60.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Clr", fontSize = 9.sp)
                    }
                }
            }
        }


        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f) // This makes the Canvas fill all remaining vertical space.
                .pointerInput(true) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()

                        val line = Line(
                            start = change.position - dragAmount,
                            end = change.position,
                            color = currentColor,
                            strokeWidth = currentStrokeWidth
                        )
                        lines.add(line)
                    }
                }
        ) {
            lines.forEach { line ->
                drawLine(
                    color = line.color,
                    start = line.start,
                    end = line.end,
                    strokeWidth = line.strokeWidth,
                    cap = StrokeCap.Round
                )
            }
        }
    }
}

@Composable
fun ColorButton(
    color: Color,
    text: String,
    textColor: Color = Color.White,
    onClick: (Color) -> Unit
) {
    Button(
        onClick = { onClick(color) },
        colors = ButtonDefaults.buttonColors(containerColor = color),
        modifier = Modifier.width(60.dp)
    ) {
        Text(text, color = textColor, fontSize = 12.sp)
    }
}